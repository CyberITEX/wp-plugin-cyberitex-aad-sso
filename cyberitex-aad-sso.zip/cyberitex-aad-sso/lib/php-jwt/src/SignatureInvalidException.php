<?php
namespace AADSSO\Firebase\JWT;

class SignatureInvalidException extends \UnexpectedValueException
{

}
