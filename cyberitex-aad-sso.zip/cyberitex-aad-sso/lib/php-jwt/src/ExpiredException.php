<?php
namespace AADSSO\Firebase\JWT;

class ExpiredException extends \UnexpectedValueException
{

}
