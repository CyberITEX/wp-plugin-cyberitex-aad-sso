<?php
namespace AADSSO\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{

}
